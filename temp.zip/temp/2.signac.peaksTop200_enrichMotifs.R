# Hua Sun
# 10/1/23

library(Seurat)
library(Signac)
library(data.table)
library(dplyr)
library(stringr)
library(GetoptLong)

library(TFBSTools)




rds <- 'celltype_hs.l5.renamed/sc_celltype_anno.rds'
sample_info <- ''
cell_info <- ''
fcell <- ''
subgroup <- 'all'

fmarker <- ''
cutoff <- 200
outdir <- 'out_peaks'

GetoptLong(
    "rds=s",        ".rds seurat file",
    "sample_info=s",   "sample info",
    'subgroup=s',      "subgroup",
    "cell_info=s",     "cell info",
    "fcell=s",         "cell list",
    "fmarker=s",    "file from FindMarker output or peaks",
    "cutoff=i",     "cutoff",
    "outdir=s",     "output path"
)




#################################
##           Set Func.
#################################

# Find closest genes for peaks
FindClosestFeatureForPeaks <- function(obj=NULL, peak_set=NULL, outfile=NULL){
    print('[INFO] find closest genes ...')
    closest_genes <- ClosestFeature(obj, regions = peak_set)
    # save peak matched gene name
    write.table(closest_genes, file = outfile, sep = "\t", row.names = F)

    return(closest_genes)
}



# https://stuartlab.org/signac/articles/pbmc_vignette.html
# Finding overrepresented motifs
RunPeakAssay_Motif <- function(obj=NULL, group='', fmarker=NULL, filter_peak=FALSE, cutoff_top=1000000000, outdir='.')
{

    #DefaultAssay(obj) <- 'peaks'
 
    diff_peaks <- read.table(fmarker, sep='\t', header=T, row.names=1)
    print(nrow(diff_peaks))

    diff_peaks$group <- group

    # 2.filter & re-sort (only use for peak-assay)
    if (filter_peak){
        print('[INFO] filtering peaks ...')
        # >10% cells open (best)
        # the best setting
        diff_peaks <- diff_peaks %>% filter(avg_log2FC>1 & p_val_adj<0.001 & pct.1>0.1 & diff_pct>0.1)

        # re-sort by 'diff_pct' - best practice
        diff_peaks <- arrange(diff_peaks, desc(diff_pct))
        # improved coverage but not specific
        #diff_peaks <- arrange(diff_peaks, p_val, desc(pct.1), desc(avg_log2FC))
        # specific but low coverage 
        #diff_peaks <- arrange(diff_peaks, p_val, desc(avg_log2FC))
        
        write.table(diff_peaks, file = paste0(outdir, '/filtered_marker_peaks.resorted.xls'), sep = "\t", quote=FALSE, col.names = NA)
        
        # top n
        diff_peaks <- head(diff_peaks, cutoff_top)
        write.table(diff_peaks, file = paste0(outdir, '/top', cutoff_top, '.open_peaks.xls'), sep = "\t", quote=FALSE, col.names = NA)
        writeLines(rownames(diff_peaks), paste0(outdir, '/top', cutoff_top, '.open_peaks.out'))

        diff_peaks$peak <- rownames(diff_peaks)
        write.table(diff_peaks[,c('peak', 'group')], file = paste0(outdir, '/top', cutoff_top, '.open_peaks.info'), sep = "\t", quote=FALSE, row.names = F, col.names=F)
    }
    print(nrow(diff_peaks))


    # 3.peak list from 'diff_peaks'
    peak_list <- rownames(diff_peaks)

    # 4.motif enrichment
    # default & set background are completely different. Use default seems good.
    print('[INFO] motif enrichment ...')
    enriched.motifs <- FindMotifs(
        object = obj,
        features = peak_list
    )

    # output enrichment motifs
    write.table(enriched.motifs, file = paste0(outdir, '/top', cutoff_top,'_peaks.enrichMotifs.default.xls'), sep = "\t", row.names = F)

    # 4.plot top9 motifs
    print('[INFO] plot top 9 motifs ...')
    p <- MotifPlot(object = obj, assay = 'peaks', motifs = head(rownames(enriched.motifs), n=9))
    pdf(paste0(outdir, '/top', cutoff_top,'_peaks.enrichedMotif.default.top9.pdf'), width = 7.5, height = 4.5, useDingbats=FALSE)
    print(p)
    dev.off()

}



#################################
##            Main
#################################

dir.create(outdir)


print('[INFO] reading .rds ...')

seurat_obj <- readRDS(rds)

DefaultAssay(seurat_obj) <- 'peaks'
print(dim(seurat_obj@meta.data))



# 2.sample info
if (nchar(sample_info)>2){
    print('[INFO] Add sample info ...')
    sample_info <- read.table(sample_info, sep='\t', header=T)
    colnames(sample_info) <- c('sample', 'group', 'subgroup')

    # add subgroup
    seurat_obj@meta.data$subgroup <- sample_info$subgroup[match(seurat_obj@meta.data$Sample, sample_info$sample)]
}


# 3.cell info for malignant cells
if (nchar(cell_info)>2){
    print('[INFO] Filter by malignant cells ...')
    cell_info <- read.table(cell_info, sep='\t', header=T, row.names=1)
    seurat_obj@meta.data$cell_status <- cell_info$cell_status[match(rownames(seurat_obj@meta.data), rownames(cell_info))]

    # only use malignant cells
    seurat_obj <- subset(x = seurat_obj, subset = cell_status == 'Malignant')
}


# 4.extract target cells
if (nchar(fcell)>2){
    print('[INFO] Filter by target cells ...')
    barcodes <- readLines(fcell)
    print(length(barcodes))
    # only use malignant cells
    seurat_obj <- subset(x = seurat_obj, cells = barcodes)
    print(nrow(seurat_obj@meta.data))
}


# 5.subgroup
if (subgroup != 'all'){
    print('[INFO] Filter by subgroup ...')
    print(subgroup)
    subgroup_set <- str_split(subgroup, ',')[[1]]
    seurat_obj <- subset(x = seurat_obj, subset = subgroup == subgroup_set)
    print(nrow(seurat_obj@meta.data))
}


print(dim(seurat_obj@meta.data))



RunPeakAssay_Motif(obj=seurat_obj, group=subgroup, fmarker=fmarker, filter_peak=TRUE, cutoff_top=cutoff, outdir=outdir)



