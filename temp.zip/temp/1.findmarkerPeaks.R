# Hua Sun
# simple version

library(Seurat)
library(Signac)
library(data.table)
library(dplyr)
library(stringr)
library(GetoptLong)



rds <- 'celltype_hs.l5.renamed/sc_celltype_anno.rds'

idents <- 'subgroup'  # cell_type2

tar <- ''
bkg <- ''

outdir <- 'out_peaks'

GetoptLong(
    "rds=s",           ".rds seurat file",
    "idents=s",        "idents",
    "tar=s",           "target",
    "bkg=s",           "background",
    "outdir=s",        "output path"
)




#################################
##           Set Func.
#################################

# Find closest genes for peaks
FindClosestFeatureForPeaks <- function(obj=NULL, peak_set=NULL, outfile=NULL){
    closest_genes <- ClosestFeature(obj, regions = peak_set)
    # save peak matched gene name
    write.table(closest_genes, file = outfile, sep = "\t", row.names = F)

    return(closest_genes)
}


# https://stuartlab.org/signac/articles/pbmc_vignette.html
# Find marker peaks
FindMarkerPeaks <- function(obj=NULL, tar=NULL, bkg=NULL)
{
    #DefaultAssay(obj) <- 'peaks'

    diff_peaks <- FindMarkers(
        object = obj,
        ident.1 = tar,
        ident.2 = bkg,
        test.use = 'LR',
        only.pos = TRUE,
        min.pct = 0.05,
        latent.vars = 'nCount_peaks',
    )

    return(diff_peaks)
    
}



# filter marker peaks
Filter_MarkerPeaks <- function(d_peaks)
{
    # >10% cells open (the best setting)
    diff_peaks <- d_peaks %>% filter(avg_log2FC>1 & p_val_adj<0.001 & pct.1>0.1 & diff_pct>0.1)
    # re-sort by 'diff_pct' - best practice
    diff_peaks <- arrange(diff_peaks, desc(diff_pct))

    return(diff_peaks)
}


#################################
##            Main
#################################


##----------- prepare -----------##

dir.create(outdir)


# 1.read object
print('[INFO] reading .rds ...')

seurat_obj <- readRDS(rds)

print(dim(seurat_obj@meta.data))

DefaultAssay(seurat_obj) <- 'peaks'
Idents(seurat_obj) <- idents
metadata <- seurat_obj@meta.data

tar <- str_split(tar, ',')[[1]]
bkg <- str_split(bkg, ',')[[1]]


print(tar)
print(bkg)



# 1.Find peak markers between two groups
print('[INFO] find peak markers ...')
diff_peaks <- FindMarkerPeaks(obj=seurat_obj, tar=tar, bkg=bkg)
diff_peaks$diff_pct = diff_peaks$pct.1 - diff_peaks$pct.2
write.table(diff_peaks, file = paste0(outdir, '/findmarker_peaks.xls'), sep = "\t", quote=FALSE, col.names = NA)

# 2.find close gene name based on peak
print('[INFO] find closest genes ...')
FindClosestFeatureForPeaks(seurat_obj, rownames(diff_peaks), paste0(outdir, '/peaks.closestGenes.xls'))


# 3.filter peaks - resort 
print('[INFO] filtering peaks ...')
diff_peaks <- Filter_MarkerPeaks(diff_peaks)
write.table(diff_peaks, file = paste0(outdir, '/findmarker_peaks.filtered_resorted.xls'), sep = "\t", quote=FALSE, col.names = NA)
# find close gene name based on peak
print('[INFO] find closest genes ...')
FindClosestFeatureForPeaks(seurat_obj, rownames(diff_peaks), paste0(outdir, '/filtered_peaks.closestGenes.xls'))





