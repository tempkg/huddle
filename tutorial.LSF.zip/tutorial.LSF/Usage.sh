
# run test
bash submit_lsf.sh
