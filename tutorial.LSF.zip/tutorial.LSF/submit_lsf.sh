#!/bin/bash
# submit_lsf.sh


mkdir -p logs

# Snakemake command
snakemake --jobs 10 \
          --cluster "bsub -M {cluster.memory} -W {cluster.time} -n {cluster.threads} -o {cluster.output} -e {cluster.error}" \
          --cluster-config cluster_config.yaml
